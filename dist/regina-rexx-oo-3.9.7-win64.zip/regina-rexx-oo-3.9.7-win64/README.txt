Regina Rexx 3.9.7 with the optional OO extension - 64-bit Windows

rexx.exe is a standalone interpreter; it needs no DLL and no installation.
Run a program with:   rexx.exe myprog.rexx

Classic Rexx programs run unchanged. Object-oriented programs can use
classes and methods (::class, ::method, ::attribute, ::routine,
::requires), messages (obj~method, obj -> method, cascades ~~ and ->>),
collections (Array, Directory, Table, Queue, Stem, ...), DO ... OVER,
DO WITH INDEX/ITEM, USE ARG and stems passed by reference.

  rexx.exe --oo prog.rexx      OO keywords on in every program
  rexx.exe --no-oo prog.rexx   OO extension off (classic Regina 3.9.7)

Manual: Regina-OO-Manual.pdf / .docx.  Samples: demo\oo\*.rexx

Error messages in other languages: set REGINA_LANG (e.g. de) and
REGINA_LANG_DIR to the folder containing the *.mtb files.

Source: https://github.com/mikebeer/REGINA2
