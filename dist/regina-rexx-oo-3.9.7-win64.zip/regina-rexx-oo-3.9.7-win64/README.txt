Regina Rexx 3.9.7 with the optional OO extension - 64-bit Windows

rexx.exe is a standalone interpreter; it needs no DLL and no installation.
Run a program with:   rexx.exe myprog.rexx

regina.exe is the same interpreter built on regina.dll. It can load
external function packages (DLLs), such as rgmqtt.dll, the MQTT client
included here (see README.rgmqtt.txt and demo\mqtt):

  regina.exe demo\mqtt\15_public_broker.rexx      uses test.mosquitto.org
  regina.exe demo\mqtt\13_mqtt.rexx localhost 1883

Keep regina.exe, regina.dll and the package DLLs in the same folder.

Deeply nested methods end with error 11 (control stack full). rexx.exe has
a 256 MB stack, regina.exe 16 MB; to use another size, start with
--stack=SIZE (for example  regina.exe --stack=512M prog.rexx) or set
REGINA_STACK=512M.

Classic Rexx programs run unchanged. Object-oriented programs can use
classes and methods (::class, ::method, ::attribute, ::routine,
::requires), messages (obj~method, obj -> method, cascades ~~ and ->>),
collections (Array, Directory, Table, Queue, Stem, ...), DO ... OVER,
DO WITH INDEX/ITEM, USE ARG and stems passed by reference.
Python modules (statistics, json, numpy, pandas, ...) are used with
.Python~import; the Python library is the folder pylib next to rexx.exe.

  rexx.exe --oo prog.rexx      OO keywords on in every program
  rexx.exe --no-oo prog.rexx   OO extension off (classic Regina 3.9.7)

Manual: Regina-OO-Manual.pdf / .docx.  Samples: demo\oo\*.rexx

Error messages in other languages: set REGINA_LANG (e.g. de) and
REGINA_LANG_DIR to the folder containing the *.mtb files.

Source: https://github.com/mikebeer/REGINA2
